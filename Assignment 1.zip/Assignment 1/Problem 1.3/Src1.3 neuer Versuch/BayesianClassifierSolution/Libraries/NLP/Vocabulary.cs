﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NLP
{
    public class Vocabulary
    {
        // Write this class - it should contain a data structure
        // that identifies all the words in the vocabulary via
        // an index. You can either use an alphabetically sorted
        // list or an instance of the Dictionary class (or
        // something else...)
    }
}
