﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NLP
{
    public class Token
    {
        public string Spelling { get; set; }

        public string POSTag { get; set; }
    }
}
