﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NLP
{
    public class TagConversionPair
    {
        // No Fields.

        // No Constructor.

        // Properties
        public string NewTag {  get; set; }
        public string OldTag { get; set; }
    }
}
